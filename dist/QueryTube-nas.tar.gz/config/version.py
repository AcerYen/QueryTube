"""QueryTube release version (single source of truth)."""

__version__ = "1.0.4"
